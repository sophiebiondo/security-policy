// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <limits>   // for std::numeric_limits

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // The account_number must remain directly before the input buffer
    const std::string account_number = "CharlieBrown42";

    // Fixed-size buffer for user input
    char user_input[20];

    std::cout << "Enter a value (max 19 characters): ";

    // Use width() to limit extraction size and prevent overflow
    std::cin.width(sizeof(user_input));
    std::cin >> user_input;

    // Check if extra characters remain in the buffer
    if (std::cin.peek() != '\n') {
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "Input exceeded buffer size. Only the first 19 characters were accepted." << std::endl;
    }


    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;
}